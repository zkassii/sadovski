# Лабораторная работа №12 — JWT и OAuth (GitHub)

Требуется .NET 8 SDK (для .NET 9 замените TargetFramework на net9.0 и версию JwtBearer на 9.0.x).

| Папка               | Задание | Запуск                           |
|---------------------|---------|----------------------------------|
| Task1_Jwt           | 5.1     | cd Task1_Jwt && dotnet run       |
| Task2_GitHubOAuth   | 5.2     | cd Task2_GitHubOAuth && dotnet run |
| Task3_Combined      | 5.3     | cd Task3_Combined && dotnet run  |

Приложения слушают http://localhost:5000 (запускайте по одному).

Перед заданиями 5.2 и 5.3 впишите ClientId и ClientSecret из GitHub в appsettings.json.
Callback URL в GitHub: http://localhost:5000/signin-github

Тестовые пользователи для JWT: admin/admin123 (Admin), user/user123 (User).
Готовые запросы — в файлах requests.http (VS Code REST Client / Rider / Visual Studio).
