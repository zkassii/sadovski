using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Читаем настройки JWT из appsettings.json (раздел "JwtSettings")
var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>()!;
var key = Encoding.ASCII.GetBytes(jwtSettings.Key);

// ---------- Аутентификация и авторизация ----------
builder.Services.AddAuthorization();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtSettings.Issuer,
            ValidateAudience = true,
            ValidAudience = jwtSettings.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero
        };
    });

// ---------- Swagger с поддержкой кнопки Authorize (Bearer) ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Lab12 JWT", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Вставьте токен, полученный из /login (слово Bearer писать не нужно)"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthentication();
app.UseAuthorization();

// "База" пользователей (для лабораторной достаточно списка в памяти)
var users = new List<AppUser>
{
    new("admin", "admin123", "Admin"),
    new("user",  "user123",  "User")
};

// ---------- Endpoint авторизации: проверяет логин/пароль и выдаёт JWT ----------
app.MapPost("/login", (LoginRequest request) =>
{
    var user = users.FirstOrDefault(u =>
        u.Username == request.Username && u.Password == request.Password);

    if (user is null)
        return Results.Unauthorized();

    var tokenHandler = new JsonWebTokenHandler();
    var tokenDescriptor = new SecurityTokenDescriptor
    {
        Subject = new ClaimsIdentity(
        [
            new Claim(ClaimTypes.NameIdentifier, user.Username),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role),
        ]),
        Expires = DateTime.UtcNow.AddMinutes(jwtSettings.AccessTokenExpirationMinutes),
        Issuer = jwtSettings.Issuer,
        Audience = jwtSettings.Audience,
        SigningCredentials = new SigningCredentials(
            new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
    };

    var token = tokenHandler.CreateToken(tokenDescriptor);
    return Results.Ok(new { token });
});

// ---------- Защищённые endpoint-ы: каждый доступен только своей роли ----------
app.MapGet("/admin/dashboard", [Authorize(Roles = "Admin")] (HttpContext context) =>
    Results.Ok(new
    {
        message = "Панель администратора (доступна только роли Admin)",
        name = context.User.Identity?.Name,
        role = context.User.FindFirst(ClaimTypes.Role)?.Value
    }));

app.MapGet("/user/orders", [Authorize(Roles = "User")] (HttpContext context) =>
    Results.Ok(new
    {
        message = "Список заказов пользователя (доступен только роли User)",
        name = context.User.Identity?.Name,
        role = context.User.FindFirst(ClaimTypes.Role)?.Value
    }));

// Корень сайта перенаправляет на Swagger
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

// ---------- Модели ----------
record LoginRequest(string Username, string Password);
record AppUser(string Username, string Password, string Role);

class JwtSettings
{
    public string Issuer { get; set; } = "";
    public string Audience { get; set; } = "";
    public string Key { get; set; } = "";
    public int AccessTokenExpirationMinutes { get; set; } = 60;
}
