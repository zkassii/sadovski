using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>()!;
var key = Encoding.ASCII.GetBytes(jwtSettings.Key);
var clientId = builder.Configuration["GitHub:ClientId"]!;
var clientSecret = builder.Configuration["GitHub:ClientSecret"]!;

const string bearer = JwtBearerDefaults.AuthenticationScheme;   // "Bearer"
const string cookies = CookieAuthenticationDefaults.AuthenticationScheme; // "Cookies"

// ---------- Все схемы аутентификации вместе ----------
builder.Services.AddAuthentication(options =>
    {
        options.DefaultScheme = cookies;
        options.DefaultChallengeScheme = "GitHub";
    })
    .AddCookie(options =>
    {
        // Для API вместо редиректа на страницу логина отдаём коды 401/403
        options.Events.OnRedirectToLogin = ctx =>
        {
            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return Task.CompletedTask;
        };
        options.Events.OnRedirectToAccessDenied = ctx =>
        {
            ctx.Response.StatusCode = StatusCodes.Status403Forbidden;
            return Task.CompletedTask;
        };
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtSettings.Issuer,
            ValidateAudience = true,
            ValidAudience = jwtSettings.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero
        };
    })
    .AddOAuth("GitHub", options =>
    {
        options.ClientId = clientId;
        options.ClientSecret = clientSecret;
        options.CallbackPath = "/signin-github";

        options.AuthorizationEndpoint = "https://github.com/login/oauth/authorize";
        options.TokenEndpoint = "https://github.com/login/oauth/access_token";
        options.UserInformationEndpoint = "https://api.github.com/user";
        options.SaveTokens = true;

        options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "id");
        options.ClaimActions.MapJsonKey(ClaimTypes.Name, "login");
        options.ClaimActions.MapJsonKey("urn:github:name", "name");
        options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email");
        options.ClaimActions.MapJsonKey("urn:github:avatar", "avatar_url");
        options.ClaimActions.MapJsonKey("urn:github:url", "html_url");

        options.Events = new OAuthEvents
        {
            OnCreatingTicket = async context =>
            {
                var request = new HttpRequestMessage(HttpMethod.Get, context.Options.UserInformationEndpoint);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", context.AccessToken);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Headers.UserAgent.ParseAdd("Lab12-Combined-App");

                var response = await context.Backchannel.SendAsync(request);
                response.EnsureSuccessStatusCode();

                using var user = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
                context.RunClaimActions(user.RootElement);
            }
        };
    });

// ---------- Политика "Profile": подходит и JWT, и Cookie (GitHub) ----------
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("Profile", policy => policy
        .AddAuthenticationSchemes(bearer, cookies)
        .RequireAuthenticatedUser());
});

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

var users = new List<AppUser>
{
    new("admin", "admin123", "Admin"),
    new("user",  "user123",  "User")
};

app.MapGet("/", () => Results.Ok(new
{
    jwt = "POST /login -> токен, затем GET /profile с заголовком Authorization: Bearer <токен>",
    github = "GET /login/github -> вход через GitHub, затем GET /profile"
}));

// ----- Вход по логину/паролю -> JWT -----
app.MapPost("/login", (LoginRequest request) =>
{
    var user = users.FirstOrDefault(u =>
        u.Username == request.Username && u.Password == request.Password);

    if (user is null)
        return Results.Unauthorized();

    var tokenHandler = new JsonWebTokenHandler();
    var tokenDescriptor = new SecurityTokenDescriptor
    {
        Subject = new ClaimsIdentity(
        [
            new Claim(ClaimTypes.NameIdentifier, user.Username),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role),
        ]),
        Expires = DateTime.UtcNow.AddMinutes(jwtSettings.AccessTokenExpirationMinutes),
        Issuer = jwtSettings.Issuer,
        Audience = jwtSettings.Audience,
        SigningCredentials = new SigningCredentials(
            new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
    };

    return Results.Ok(new { token = tokenHandler.CreateToken(tokenDescriptor) });
});

// ----- Вход через GitHub -> Cookie -----
app.MapGet("/login/github", async (HttpContext context) =>
{
    await context.ChallengeAsync("GitHub", new AuthenticationProperties { RedirectUri = "/profile" });
});

app.MapGet("/logout", async (HttpContext context) =>
{
    await context.SignOutAsync(cookies);
    return Results.Redirect("/");
});

// ----- Профиль: работает при любом способе входа -----
app.MapGet("/profile", (HttpContext context) =>
    Results.Ok(new
    {
        name = context.User.Identity?.Name,
        role = context.User.FindFirst(ClaimTypes.Role)?.Value ?? "нет (вход через GitHub)",
        authenticationType = context.User.Identity?.AuthenticationType,
        email = context.User.FindFirst(ClaimTypes.Email)?.Value,
        avatar = context.User.FindFirst("urn:github:avatar")?.Value
    }))
    .RequireAuthorization("Profile");

// ----- Ролевые endpoint-ы из задания 5.1 (только по JWT) -----
app.MapGet("/admin/dashboard",
    [Authorize(AuthenticationSchemes = bearer, Roles = "Admin")] (HttpContext context) =>
    Results.Ok(new
    {
        message = "Панель администратора",
        name = context.User.Identity?.Name,
        role = context.User.FindFirst(ClaimTypes.Role)?.Value
    }));

app.MapGet("/user/orders",
    [Authorize(AuthenticationSchemes = bearer, Roles = "User")] (HttpContext context) =>
    Results.Ok(new
    {
        message = "Заказы пользователя",
        name = context.User.Identity?.Name,
        role = context.User.FindFirst(ClaimTypes.Role)?.Value
    }));

app.Run();

record LoginRequest(string Username, string Password);
record AppUser(string Username, string Password, string Role);

class JwtSettings
{
    public string Issuer { get; set; } = "";
    public string Audience { get; set; } = "";
    public string Key { get; set; } = "";
    public int AccessTokenExpirationMinutes { get; set; } = 60;
}
