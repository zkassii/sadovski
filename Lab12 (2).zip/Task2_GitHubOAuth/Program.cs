using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

var clientId = builder.Configuration["GitHub:ClientId"]!;
var clientSecret = builder.Configuration["GitHub:ClientSecret"]!;

// ---------- Аутентификация: Cookie (хранит сессию) + OAuth (вход через GitHub) ----------
builder.Services.AddAuthentication(options =>
    {
        // Кто хранит "вошёл ли пользователь" после входа
        options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
        // Куда отправлять неавторизованного пользователя
        options.DefaultChallengeScheme = "GitHub";
    })
    .AddCookie()
    .AddOAuth("GitHub", options =>
    {
        // Данные приложения из GitHub (Settings -> Developer settings -> OAuth Apps)
        options.ClientId = clientId;
        options.ClientSecret = clientSecret;

        // Должен совпадать с Authorization callback URL в GitHub.
        // Этот путь обрабатывает сам OAuth-middleware, создавать для него endpoint не нужно.
        options.CallbackPath = "/signin-github";

        // Адреса из документации GitHub (шаги 1, 2 и 3)
        options.AuthorizationEndpoint = "https://github.com/login/oauth/authorize";
        options.TokenEndpoint = "https://github.com/login/oauth/access_token";
        options.UserInformationEndpoint = "https://api.github.com/user";

        options.SaveTokens = true;

        // ClaimActions: поле JSON из ответа GitHub -> claim пользователя
        options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "id");
        options.ClaimActions.MapJsonKey(ClaimTypes.Name, "login");
        options.ClaimActions.MapJsonKey("urn:github:name", "name");
        options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email");
        options.ClaimActions.MapJsonKey("urn:github:avatar", "avatar_url");
        options.ClaimActions.MapJsonKey("urn:github:url", "html_url");

        options.Events = new OAuthEvents
        {
            // Вызывается, когда токен получен: идём в API GitHub за данными пользователя
            OnCreatingTicket = async context =>
            {
                var request = new HttpRequestMessage(HttpMethod.Get, context.Options.UserInformationEndpoint);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", context.AccessToken);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Headers.UserAgent.ParseAdd("Lab12-OAuth-App");

                var response = await context.Backchannel.SendAsync(request);
                response.EnsureSuccessStatusCode();

                using var user = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
                context.RunClaimActions(user.RootElement);
            }
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/", () => Results.Ok(new
{
    message = "Откройте /login для входа через GitHub, затем /me для информации о себе"
}));

// Запуск входа: перенаправляет на GitHub, после успеха вернёт на /me
app.MapGet("/login", async (HttpContext context) =>
{
    await context.ChallengeAsync("GitHub", new AuthenticationProperties { RedirectUri = "/me" });
});

// Информация об авторизованном пользователе (берётся из context.User)
app.MapGet("/me", [Authorize] (HttpContext context) =>
    Results.Ok(new
    {
        name = context.User.Identity?.Name,
        id = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value,
        fullName = context.User.FindFirst("urn:github:name")?.Value,
        email = context.User.FindFirst(ClaimTypes.Email)?.Value,
        avatar = context.User.FindFirst("urn:github:avatar")?.Value,
        profileUrl = context.User.FindFirst("urn:github:url")?.Value
    }));

// Выход: удаляем cookie
app.MapGet("/logout", async (HttpContext context) =>
{
    await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/");
});

app.Run();
